chnum=4
latex=/home/nlevisrael/texlive/bin/x86_64-linux/pdflatex 
$latex -interaction=nonstopmode --shell-escape -output-dir=out \
--jobname=ScignTorq-gen '\def\briefSectionGap{0} \input{ScignTorq.gen.tex}'

